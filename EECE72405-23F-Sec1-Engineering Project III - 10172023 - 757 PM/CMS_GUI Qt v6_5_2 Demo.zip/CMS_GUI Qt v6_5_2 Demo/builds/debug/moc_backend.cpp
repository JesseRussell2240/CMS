/****************************************************************************
** Meta object code from reading C++ file 'backend.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../backend.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'backend.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSBackEndENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSBackEndENDCLASS = QtMocHelpers::stringData(
    "BackEnd",
    "TxTextChanged",
    "",
    "RxTextChanged",
    "priorityChanged",
    "sampleRateChanged",
    "recTimeChanged",
    "bitRateChanged",
    "comPortChanged",
    "rxIDChanged",
    "txIDChanged",
    "encChanged",
    "cmpChanged",
    "timeoutChanged",
    "optionsChanged",
    "ptyChanged",
    "rxAudTextChanged",
    "countRxTextQueueChanged",
    "countRxAudioQueueChanged",
    "transmitText",
    "genQuote",
    "recordAudio",
    "playAudio",
    "saveAudio",
    "loadAudio",
    "transmitAudio",
    "receiveText",
    "viewText",
    "receiveAudio",
    "playReceivedAudio",
    "TxText",
    "RxText",
    "priority",
    "sampleRate",
    "recTime",
    "bitRate",
    "comPort",
    "rxID",
    "txID",
    "enc",
    "cmp",
    "timeout",
    "options",
    "pty",
    "rxAudText",
    "countRxTextQueue",
    "countRxAudioQueue"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSBackEndENDCLASS_t {
    uint offsetsAndSizes[94];
    char stringdata0[8];
    char stringdata1[14];
    char stringdata2[1];
    char stringdata3[14];
    char stringdata4[16];
    char stringdata5[18];
    char stringdata6[15];
    char stringdata7[15];
    char stringdata8[15];
    char stringdata9[12];
    char stringdata10[12];
    char stringdata11[11];
    char stringdata12[11];
    char stringdata13[15];
    char stringdata14[15];
    char stringdata15[11];
    char stringdata16[17];
    char stringdata17[24];
    char stringdata18[25];
    char stringdata19[13];
    char stringdata20[9];
    char stringdata21[12];
    char stringdata22[10];
    char stringdata23[10];
    char stringdata24[10];
    char stringdata25[14];
    char stringdata26[12];
    char stringdata27[9];
    char stringdata28[13];
    char stringdata29[18];
    char stringdata30[7];
    char stringdata31[7];
    char stringdata32[9];
    char stringdata33[11];
    char stringdata34[8];
    char stringdata35[8];
    char stringdata36[8];
    char stringdata37[5];
    char stringdata38[5];
    char stringdata39[4];
    char stringdata40[4];
    char stringdata41[8];
    char stringdata42[8];
    char stringdata43[4];
    char stringdata44[10];
    char stringdata45[17];
    char stringdata46[18];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSBackEndENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSBackEndENDCLASS_t qt_meta_stringdata_CLASSBackEndENDCLASS = {
    {
        QT_MOC_LITERAL(0, 7),  // "BackEnd"
        QT_MOC_LITERAL(8, 13),  // "TxTextChanged"
        QT_MOC_LITERAL(22, 0),  // ""
        QT_MOC_LITERAL(23, 13),  // "RxTextChanged"
        QT_MOC_LITERAL(37, 15),  // "priorityChanged"
        QT_MOC_LITERAL(53, 17),  // "sampleRateChanged"
        QT_MOC_LITERAL(71, 14),  // "recTimeChanged"
        QT_MOC_LITERAL(86, 14),  // "bitRateChanged"
        QT_MOC_LITERAL(101, 14),  // "comPortChanged"
        QT_MOC_LITERAL(116, 11),  // "rxIDChanged"
        QT_MOC_LITERAL(128, 11),  // "txIDChanged"
        QT_MOC_LITERAL(140, 10),  // "encChanged"
        QT_MOC_LITERAL(151, 10),  // "cmpChanged"
        QT_MOC_LITERAL(162, 14),  // "timeoutChanged"
        QT_MOC_LITERAL(177, 14),  // "optionsChanged"
        QT_MOC_LITERAL(192, 10),  // "ptyChanged"
        QT_MOC_LITERAL(203, 16),  // "rxAudTextChanged"
        QT_MOC_LITERAL(220, 23),  // "countRxTextQueueChanged"
        QT_MOC_LITERAL(244, 24),  // "countRxAudioQueueChanged"
        QT_MOC_LITERAL(269, 12),  // "transmitText"
        QT_MOC_LITERAL(282, 8),  // "genQuote"
        QT_MOC_LITERAL(291, 11),  // "recordAudio"
        QT_MOC_LITERAL(303, 9),  // "playAudio"
        QT_MOC_LITERAL(313, 9),  // "saveAudio"
        QT_MOC_LITERAL(323, 9),  // "loadAudio"
        QT_MOC_LITERAL(333, 13),  // "transmitAudio"
        QT_MOC_LITERAL(347, 11),  // "receiveText"
        QT_MOC_LITERAL(359, 8),  // "viewText"
        QT_MOC_LITERAL(368, 12),  // "receiveAudio"
        QT_MOC_LITERAL(381, 17),  // "playReceivedAudio"
        QT_MOC_LITERAL(399, 6),  // "TxText"
        QT_MOC_LITERAL(406, 6),  // "RxText"
        QT_MOC_LITERAL(413, 8),  // "priority"
        QT_MOC_LITERAL(422, 10),  // "sampleRate"
        QT_MOC_LITERAL(433, 7),  // "recTime"
        QT_MOC_LITERAL(441, 7),  // "bitRate"
        QT_MOC_LITERAL(449, 7),  // "comPort"
        QT_MOC_LITERAL(457, 4),  // "rxID"
        QT_MOC_LITERAL(462, 4),  // "txID"
        QT_MOC_LITERAL(467, 3),  // "enc"
        QT_MOC_LITERAL(471, 3),  // "cmp"
        QT_MOC_LITERAL(475, 7),  // "timeout"
        QT_MOC_LITERAL(483, 7),  // "options"
        QT_MOC_LITERAL(491, 3),  // "pty"
        QT_MOC_LITERAL(495, 9),  // "rxAudText"
        QT_MOC_LITERAL(505, 16),  // "countRxTextQueue"
        QT_MOC_LITERAL(522, 17)   // "countRxAudioQueue"
    },
    "BackEnd",
    "TxTextChanged",
    "",
    "RxTextChanged",
    "priorityChanged",
    "sampleRateChanged",
    "recTimeChanged",
    "bitRateChanged",
    "comPortChanged",
    "rxIDChanged",
    "txIDChanged",
    "encChanged",
    "cmpChanged",
    "timeoutChanged",
    "optionsChanged",
    "ptyChanged",
    "rxAudTextChanged",
    "countRxTextQueueChanged",
    "countRxAudioQueueChanged",
    "transmitText",
    "genQuote",
    "recordAudio",
    "playAudio",
    "saveAudio",
    "loadAudio",
    "transmitAudio",
    "receiveText",
    "viewText",
    "receiveAudio",
    "playReceivedAudio",
    "TxText",
    "RxText",
    "priority",
    "sampleRate",
    "recTime",
    "bitRate",
    "comPort",
    "rxID",
    "txID",
    "enc",
    "cmp",
    "timeout",
    "options",
    "pty",
    "rxAudText",
    "countRxTextQueue",
    "countRxAudioQueue"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSBackEndENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
      28,   14, // methods
      17,  210, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      17,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  182,    2, 0x06,   18 /* Public */,
       3,    0,  183,    2, 0x06,   19 /* Public */,
       4,    0,  184,    2, 0x06,   20 /* Public */,
       5,    0,  185,    2, 0x06,   21 /* Public */,
       6,    0,  186,    2, 0x06,   22 /* Public */,
       7,    0,  187,    2, 0x06,   23 /* Public */,
       8,    0,  188,    2, 0x06,   24 /* Public */,
       9,    0,  189,    2, 0x06,   25 /* Public */,
      10,    0,  190,    2, 0x06,   26 /* Public */,
      11,    0,  191,    2, 0x06,   27 /* Public */,
      12,    0,  192,    2, 0x06,   28 /* Public */,
      13,    0,  193,    2, 0x06,   29 /* Public */,
      14,    0,  194,    2, 0x06,   30 /* Public */,
      15,    0,  195,    2, 0x06,   31 /* Public */,
      16,    0,  196,    2, 0x06,   32 /* Public */,
      17,    0,  197,    2, 0x06,   33 /* Public */,
      18,    0,  198,    2, 0x06,   34 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
      19,    0,  199,    2, 0x0a,   35 /* Public */,
      20,    0,  200,    2, 0x0a,   36 /* Public */,
      21,    0,  201,    2, 0x0a,   37 /* Public */,
      22,    0,  202,    2, 0x0a,   38 /* Public */,
      23,    0,  203,    2, 0x0a,   39 /* Public */,
      24,    0,  204,    2, 0x0a,   40 /* Public */,
      25,    0,  205,    2, 0x0a,   41 /* Public */,
      26,    0,  206,    2, 0x0a,   42 /* Public */,
      27,    0,  207,    2, 0x0a,   43 /* Public */,
      28,    0,  208,    2, 0x0a,   44 /* Public */,
      29,    0,  209,    2, 0x0a,   45 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // properties: name, type, flags
      30, QMetaType::QString, 0x00015103, uint(0), 0,
      31, QMetaType::QString, 0x00015103, uint(1), 0,
      32, QMetaType::QString, 0x00015103, uint(2), 0,
      33, QMetaType::QString, 0x00015103, uint(3), 0,
      34, QMetaType::Int, 0x00015103, uint(4), 0,
      35, QMetaType::QString, 0x00015103, uint(5), 0,
      36, QMetaType::QString, 0x00015103, uint(6), 0,
      37, QMetaType::QString, 0x00015103, uint(7), 0,
      38, QMetaType::QString, 0x00015103, uint(8), 0,
      39, QMetaType::QString, 0x00015003, uint(9), 0,
      40, QMetaType::QString, 0x00015003, uint(10), 0,
      41, QMetaType::QString, 0x00015103, uint(11), 0,
      42, QMetaType::QString, 0x00015103, uint(12), 0,
      43, QMetaType::Bool, 0x00015103, uint(13), 0,
      44, QMetaType::QString, 0x00015103, uint(14), 0,
      45, QMetaType::Int, 0x00015103, uint(15), 0,
      46, QMetaType::Int, 0x00015103, uint(16), 0,

       0        // eod
};

Q_CONSTINIT const QMetaObject BackEnd::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_CLASSBackEndENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSBackEndENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSBackEndENDCLASS_t,
        // property 'TxText'
        QtPrivate::TypeAndForceComplete<QString, std::true_type>,
        // property 'RxText'
        QtPrivate::TypeAndForceComplete<QString, std::true_type>,
        // property 'priority'
        QtPrivate::TypeAndForceComplete<QString, std::true_type>,
        // property 'sampleRate'
        QtPrivate::TypeAndForceComplete<QString, std::true_type>,
        // property 'recTime'
        QtPrivate::TypeAndForceComplete<int, std::true_type>,
        // property 'bitRate'
        QtPrivate::TypeAndForceComplete<QString, std::true_type>,
        // property 'comPort'
        QtPrivate::TypeAndForceComplete<QString, std::true_type>,
        // property 'rxID'
        QtPrivate::TypeAndForceComplete<QString, std::true_type>,
        // property 'txID'
        QtPrivate::TypeAndForceComplete<QString, std::true_type>,
        // property 'enc'
        QtPrivate::TypeAndForceComplete<QString, std::true_type>,
        // property 'cmp'
        QtPrivate::TypeAndForceComplete<QString, std::true_type>,
        // property 'timeout'
        QtPrivate::TypeAndForceComplete<QString, std::true_type>,
        // property 'options'
        QtPrivate::TypeAndForceComplete<QString, std::true_type>,
        // property 'pty'
        QtPrivate::TypeAndForceComplete<bool, std::true_type>,
        // property 'rxAudText'
        QtPrivate::TypeAndForceComplete<QString, std::true_type>,
        // property 'countRxTextQueue'
        QtPrivate::TypeAndForceComplete<int, std::true_type>,
        // property 'countRxAudioQueue'
        QtPrivate::TypeAndForceComplete<int, std::true_type>,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<BackEnd, std::true_type>,
        // method 'TxTextChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'RxTextChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'priorityChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'sampleRateChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'recTimeChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'bitRateChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'comPortChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'rxIDChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'txIDChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'encChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'cmpChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'timeoutChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'optionsChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'ptyChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'rxAudTextChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'countRxTextQueueChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'countRxAudioQueueChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'transmitText'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'genQuote'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'recordAudio'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'playAudio'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'saveAudio'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'loadAudio'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'transmitAudio'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'receiveText'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'viewText'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'receiveAudio'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'playReceivedAudio'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void BackEnd::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<BackEnd *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->TxTextChanged(); break;
        case 1: _t->RxTextChanged(); break;
        case 2: _t->priorityChanged(); break;
        case 3: _t->sampleRateChanged(); break;
        case 4: _t->recTimeChanged(); break;
        case 5: _t->bitRateChanged(); break;
        case 6: _t->comPortChanged(); break;
        case 7: _t->rxIDChanged(); break;
        case 8: _t->txIDChanged(); break;
        case 9: _t->encChanged(); break;
        case 10: _t->cmpChanged(); break;
        case 11: _t->timeoutChanged(); break;
        case 12: _t->optionsChanged(); break;
        case 13: _t->ptyChanged(); break;
        case 14: _t->rxAudTextChanged(); break;
        case 15: _t->countRxTextQueueChanged(); break;
        case 16: _t->countRxAudioQueueChanged(); break;
        case 17: _t->transmitText(); break;
        case 18: _t->genQuote(); break;
        case 19: _t->recordAudio(); break;
        case 20: _t->playAudio(); break;
        case 21: _t->saveAudio(); break;
        case 22: _t->loadAudio(); break;
        case 23: _t->transmitAudio(); break;
        case 24: _t->receiveText(); break;
        case 25: _t->viewText(); break;
        case 26: _t->receiveAudio(); break;
        case 27: _t->playReceivedAudio(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (BackEnd::*)();
            if (_t _q_method = &BackEnd::TxTextChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (BackEnd::*)();
            if (_t _q_method = &BackEnd::RxTextChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (BackEnd::*)();
            if (_t _q_method = &BackEnd::priorityChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (BackEnd::*)();
            if (_t _q_method = &BackEnd::sampleRateChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (BackEnd::*)();
            if (_t _q_method = &BackEnd::recTimeChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (BackEnd::*)();
            if (_t _q_method = &BackEnd::bitRateChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (BackEnd::*)();
            if (_t _q_method = &BackEnd::comPortChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (BackEnd::*)();
            if (_t _q_method = &BackEnd::rxIDChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (BackEnd::*)();
            if (_t _q_method = &BackEnd::txIDChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 8;
                return;
            }
        }
        {
            using _t = void (BackEnd::*)();
            if (_t _q_method = &BackEnd::encChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 9;
                return;
            }
        }
        {
            using _t = void (BackEnd::*)();
            if (_t _q_method = &BackEnd::cmpChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 10;
                return;
            }
        }
        {
            using _t = void (BackEnd::*)();
            if (_t _q_method = &BackEnd::timeoutChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 11;
                return;
            }
        }
        {
            using _t = void (BackEnd::*)();
            if (_t _q_method = &BackEnd::optionsChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 12;
                return;
            }
        }
        {
            using _t = void (BackEnd::*)();
            if (_t _q_method = &BackEnd::ptyChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 13;
                return;
            }
        }
        {
            using _t = void (BackEnd::*)();
            if (_t _q_method = &BackEnd::rxAudTextChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 14;
                return;
            }
        }
        {
            using _t = void (BackEnd::*)();
            if (_t _q_method = &BackEnd::countRxTextQueueChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 15;
                return;
            }
        }
        {
            using _t = void (BackEnd::*)();
            if (_t _q_method = &BackEnd::countRxAudioQueueChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 16;
                return;
            }
        }
    }else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<BackEnd *>(_o);
        (void)_t;
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QString*>(_v) = _t->TxText(); break;
        case 1: *reinterpret_cast< QString*>(_v) = _t->RxText(); break;
        case 2: *reinterpret_cast< QString*>(_v) = _t->priority(); break;
        case 3: *reinterpret_cast< QString*>(_v) = _t->sampleRate(); break;
        case 4: *reinterpret_cast< int*>(_v) = _t->recTime(); break;
        case 5: *reinterpret_cast< QString*>(_v) = _t->bitRate(); break;
        case 6: *reinterpret_cast< QString*>(_v) = _t->comPort(); break;
        case 7: *reinterpret_cast< QString*>(_v) = _t->rxID(); break;
        case 8: *reinterpret_cast< QString*>(_v) = _t->txID(); break;
        case 9: *reinterpret_cast< QString*>(_v) = _t->enc(); break;
        case 10: *reinterpret_cast< QString*>(_v) = _t->cmp(); break;
        case 11: *reinterpret_cast< QString*>(_v) = _t->timeout(); break;
        case 12: *reinterpret_cast< QString*>(_v) = _t->options(); break;
        case 13: *reinterpret_cast< bool*>(_v) = _t->pty(); break;
        case 14: *reinterpret_cast< QString*>(_v) = _t->rxAudText(); break;
        case 15: *reinterpret_cast< int*>(_v) = _t->countRxTextQueue(); break;
        case 16: *reinterpret_cast< int*>(_v) = _t->countRxAudioQueue(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = static_cast<BackEnd *>(_o);
        (void)_t;
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setTxText(*reinterpret_cast< QString*>(_v)); break;
        case 1: _t->setRxText(*reinterpret_cast< QString*>(_v)); break;
        case 2: _t->setPriority(*reinterpret_cast< QString*>(_v)); break;
        case 3: _t->setSampleRate(*reinterpret_cast< QString*>(_v)); break;
        case 4: _t->setRecTime(*reinterpret_cast< int*>(_v)); break;
        case 5: _t->setBitRate(*reinterpret_cast< QString*>(_v)); break;
        case 6: _t->setComPort(*reinterpret_cast< QString*>(_v)); break;
        case 7: _t->setRxID(*reinterpret_cast< QString*>(_v)); break;
        case 8: _t->setTxID(*reinterpret_cast< QString*>(_v)); break;
        case 9: _t->setenc(*reinterpret_cast< QString*>(_v)); break;
        case 10: _t->setcmp(*reinterpret_cast< QString*>(_v)); break;
        case 11: _t->setTimeout(*reinterpret_cast< QString*>(_v)); break;
        case 12: _t->setOptions(*reinterpret_cast< QString*>(_v)); break;
        case 13: _t->setPty(*reinterpret_cast< bool*>(_v)); break;
        case 14: _t->setRxAudText(*reinterpret_cast< QString*>(_v)); break;
        case 15: _t->setCountRxTextQueue(*reinterpret_cast< int*>(_v)); break;
        case 16: _t->setCountRxAudioQueue(*reinterpret_cast< int*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    } else if (_c == QMetaObject::BindableProperty) {
    }
    (void)_a;
}

const QMetaObject *BackEnd::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *BackEnd::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSBackEndENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int BackEnd::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 28)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 28;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 28)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 28;
    }else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::BindableProperty
            || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 17;
    }
    return _id;
}

// SIGNAL 0
void BackEnd::TxTextChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void BackEnd::RxTextChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void BackEnd::priorityChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void BackEnd::sampleRateChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void BackEnd::recTimeChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void BackEnd::bitRateChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}

// SIGNAL 6
void BackEnd::comPortChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 6, nullptr);
}

// SIGNAL 7
void BackEnd::rxIDChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 7, nullptr);
}

// SIGNAL 8
void BackEnd::txIDChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 8, nullptr);
}

// SIGNAL 9
void BackEnd::encChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 9, nullptr);
}

// SIGNAL 10
void BackEnd::cmpChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 10, nullptr);
}

// SIGNAL 11
void BackEnd::timeoutChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 11, nullptr);
}

// SIGNAL 12
void BackEnd::optionsChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 12, nullptr);
}

// SIGNAL 13
void BackEnd::ptyChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 13, nullptr);
}

// SIGNAL 14
void BackEnd::rxAudTextChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 14, nullptr);
}

// SIGNAL 15
void BackEnd::countRxTextQueueChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 15, nullptr);
}

// SIGNAL 16
void BackEnd::countRxAudioQueueChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 16, nullptr);
}
QT_WARNING_POP
